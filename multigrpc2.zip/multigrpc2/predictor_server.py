import grpc
from concurrent import futures
import time
import os
import threading
import predictor_pb2_grpc as pb2_grpc
import predictor_pb2 as pb2
from multiprocessing import Process


NUM_WORKERS = 8
NUM_THREADS = 10
LISTEN_PORT = 50051
PROXY_START_PORT = 50055

class PredictorService(pb2_grpc.PredictorServicer):

    def __init__(self, *args, **kwargs):
        pass

    def Predict(self, request, context):
        image_bytes = request.image_bytes
        time.sleep(1)
        response = pb2.PredictResponse(templates=[pb2.Template(name=f'process id={os.getpid()} and thread id={threading.get_native_id()}')])
        return response


class PredictorProxyService():

    def __init__(self, port, threads, *args, **kwargs):
        self.port = port
        self.threads = threads
        self.process = Process(target=self.start_predictor_service)
        self.process.start()
        self.channel = grpc.insecure_channel(f'localhost:{self.port}')
        self.stub = pb2_grpc.PredictorStub(self.channel)

    def start_predictor_service(self):
        server = grpc.server(futures.ThreadPoolExecutor(max_workers=self.threads))
        pb2_grpc.add_PredictorServicer_to_server(PredictorService(), server)
        server.add_insecure_port(f'[::]:{self.port}')
        server.start()
        server.wait_for_termination()
    
    def Predict(self, request, context):
        predict_request = pb2.PredictRequest(image_bytes=request.image_bytes)
        predict_response = self.stub.Predict(predict_request)
        return predict_response
        
    def __enter__(self):
        return self

    def __exit__(self, exc, value, tb):
        self.channel.close()
        self.process.join()




class PredictorRelayService(pb2_grpc.PredictorServicer):

    def __init__(self, workers, threads, start_port, *args, **kwargs):
        self.request_count = 0
        self.workers = workers
        self.threads = threads
        self.start_port = start_port
        self.proxy_services = []

    def Predict(self, request, context):
        service = self.get_service()
        return service.Predict(request, context)

    def get_service(self):
        self.request_count += 1
        if self.request_count > 100000:
            self.request_count = 0

        return self.proxy_services[self.request_count % self.workers]  

    def __enter__(self):
        for i in range(self.workers):
            self.proxy_services.append(PredictorProxyService(self.start_port + i, self.threads))
        return self

    def __exit__(self, exc, value, tb):
        for i in range(len(self.proxy_services)):
            self.proxy_services[i].__exit__(exc, value, tb)


def serve_relay():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=NUM_WORKERS * NUM_THREADS))
    with PredictorRelayService(NUM_WORKERS, NUM_THREADS, PROXY_START_PORT) as relay_service:
        pb2_grpc.add_PredictorServicer_to_server(relay_service, server)
        server.add_insecure_port(f'[::]:{LISTEN_PORT}')
        server.start()
        server.wait_for_termination()


if __name__ == '__main__':
    serve_relay()