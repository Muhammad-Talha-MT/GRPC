import grpc
from concurrent import futures
import time
import os
import threading
import unary_pb2_grpc as pb2_grpc
import unary_pb2 as pb2
from multiprocessing import Pool, Process


NUM_WORKERS = 8
NUM_THREADS = 10

class PredictorService(pb2_grpc.UnaryServicer):

    def __init__(self, *args, **kwargs):
        pass

    def GetServerResponse(self, request, context):
        time.sleep(2)
        # get the string from the incoming request
        message = request.message
        result = f'Hello I am up and running received "{message}" message from you in process id={os.getpid()} and thread id={threading.get_native_id()}'
        result = {'message': result, 'received': True}

        return pb2.MessageResponse(**result)


class PredictorProxyService():

    def __init__(self, port, threads, *args, **kwargs):
        self.port = port
        self.threads = threads
        self.process = Process(target=self.start_predictor_service)
        self.process.start()
        self.channel = grpc.insecure_channel(f'localhost:{self.port}')
        self.stub = pb2_grpc.UnaryStub(self.channel)

    def start_predictor_service(self):
        server = grpc.server(futures.ThreadPoolExecutor(max_workers=self.threads))
        pb2_grpc.add_UnaryServicer_to_server(PredictorService(), server)
        server.add_insecure_port(f'[::]:{self.port}')
        server.start()
        server.wait_for_termination()
    
    def GetServerResponse(self, request, context):
        message = pb2.Message(message=request.message)
        print(f'Request: {message}')
        response_message = self.stub.GetServerResponse(message)
        print(f'Response: {response_message}')
        return response_message
        
    def __enter__(self):
        return self

    def __exit__(self, exc, value, tb):
        self.channel.close()
        self.process.join()


class PredictorRelayService(pb2_grpc.UnaryServicer):

    def __init__(self, workers, threads, start_port, *args, **kwargs):
        self.request_count = 0
        self.workers = workers
        self.threads = threads
        self.start_port = start_port
        self.proxy_services = []

    def GetServerResponse(self, request, context):
        service = self.get_service()
        return service.GetServerResponse(request, context)

    def get_service(self):
        self.request_count += 1
        if self.request_count > 100000:
            self.request_count = 0

        return self.proxy_services[self.request_count % self.workers]  

    def __enter__(self):
        for i in range(self.workers):
            self.proxy_services.append(PredictorProxyService(self.start_port + i, self.threads))
        return self

    def __exit__(self, exc, value, tb):
        for i in range(len(self.proxy_services)):
            self.proxy_services[i].__exit__(exc, value, tb)


def serve_proxy():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=NUM_WORKERS * NUM_THREADS))
    with PredictorRelayService(NUM_WORKERS, NUM_THREADS, 50055) as relay_service:
        pb2_grpc.add_UnaryServicer_to_server(relay_service, server)
        server.add_insecure_port('[::]:50051')
        server.start()
        server.wait_for_termination()


if __name__ == '__main__':
    serve_proxy()