import grpc
import predictor_pb2_grpc as pb2_grpc
import predictor_pb2 as pb2
from multiprocessing import Pool

class PredictorClient(object):
    """
    Client for gRPC functionality
    """

    def __init__(self):
        self.host = 'localhost'
        self.server_port = 50051

        # instantiate a channel
        self.channel = grpc.insecure_channel(
            '{}:{}'.format(self.host, self.server_port))

        # bind the client and the server
        self.stub = pb2_grpc.PredictorStub(self.channel)

    def get_url(self):
        """
        Client function to call the rpc for GetServerResponse
        """
        predict_request = pb2.PredictRequest(image_bytes=b'')
        print(f'{predict_request}')
        return self.stub.Predict(predict_request)


def do_message(wid):
    client = PredictorClient()
    result = client.get_url()
    print(f'{result}')

if __name__ == '__main__':
    # threads = []
    # num_threads = 5
    # for _ in range(num_threads):
    #     t = threading.Thread(target=do_message, args=())
    #     t.start()
    #     threads.append(t)

    # for i in range(num_threads):
    #     threads[i].join()
    with Pool(16) as pool:
        pool.map(do_message, range(16))


