import time
import multiprocessing as mp


def run(index):
    print(f'{index}: Run Begin')
    time.sleep(2)
    print(f'{index}: Run End')


if __name__ == '__main__':
    index = 0
    with mp.Pool(1) as pool:
        print('Forwarding request 1')
        pool.apply_async(run, (1,))
        print('Forwarding request 2')
        pool.apply_async(run, (2,))
        pool.close()
        pool.join()