import grpc
import unary_pb2_grpc as pb2_grpc
import unary_pb2 as pb2
import threading
from multiprocessing import Pool

class UnaryClient(object):
    """
    Client for gRPC functionality
    """

    def __init__(self):
        self.host = 'localhost'
        self.server_port = 50051

        # instantiate a channel
        self.channel = grpc.insecure_channel(
            '{}:{}'.format(self.host, self.server_port))

        # bind the client and the server
        self.stub = pb2_grpc.UnaryStub(self.channel)

    def get_url(self, message):
        """
        Client function to call the rpc for GetServerResponse
        """
        message = pb2.Message(message=message)
        print(f'{message}')
        return self.stub.GetServerResponse(message)


def do_message(wid):
    client = UnaryClient()
    result = client.get_url(message=f"Worker Id={wid} Hello Server you there?")
    print(f'{result}')

if __name__ == '__main__':
    # threads = []
    # num_threads = 5
    # for _ in range(num_threads):
    #     t = threading.Thread(target=do_message, args=())
    #     t.start()
    #     threads.append(t)

    # for i in range(num_threads):
    #     threads[i].join()
    with Pool(5) as pool:
        pool.map(do_message, range(5))


